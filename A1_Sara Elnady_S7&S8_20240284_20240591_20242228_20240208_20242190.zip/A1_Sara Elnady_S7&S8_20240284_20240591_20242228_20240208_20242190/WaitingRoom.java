import java.util.LinkedList;
import java.util.Queue;

public class WaitingRoom {

    private Queue<Patient> queue;

    private Semaphore spaces;
    private Semaphore patients;
    private Semaphore lock;

    public WaitingRoom(int capacity) {

        if (capacity <= 0) {
            throw new IllegalArgumentException("Invalid capacity");
        }

        queue = new LinkedList<>();

        spaces = new Semaphore(capacity);
        patients = new Semaphore(0);
        lock = new Semaphore(1);
    }
//*******
    public void addPatient(Patient patient) throws InterruptedException {

        if (!spaces.tryP(0)) {
            System.out.println("The waiting room is full.");
            System.out.println(patient.getName()
                    + " is waiting outside for an available seat.");

            spaces.P();
        }

        try {
            lock.P();

            try {
                queue.add(patient);
            } finally {
                lock.V();
            }

        } catch (InterruptedException e) {
            spaces.V();
            throw e;
        }

        patients.V();
    }
//*******
   public Patient removePatient() throws InterruptedException {

    patients.P();

    try {
        lock.P();
    } catch (InterruptedException e) {
        patients.V();    // نطلع المريض من الطابور للدكتور يعالجه

        throw e;
    }

    try {
        return queue.remove();
    } finally {
        lock.V();
    }
}


    // يتم استدعاؤها بعد حجز غرفة العلاج بنجاح: يغادر المريض صالة الانتظار ويفرغ مكاناً
    public void releaseSpace() {
        spaces.V();
    }

    // يتم استدعاؤها عند فشل حجز غرفة العلاج: يعود المريض إلى الطابور دون حجز مكان جديد
    public void returnPatient(Patient patient) throws InterruptedException {
        lock.P();
        try {
            queue.add(patient);
        } finally {
            lock.V();
        }
        patients.V();
    }

    public int getWaitingCount() throws InterruptedException {

        lock.P(); // استنى لحد ما محدش يكون بيعدّل الـ Queue، وبعدها اقرأ العدد.
        try {
            return queue.size();
        } finally {
            lock.V();
        }

    }
}
